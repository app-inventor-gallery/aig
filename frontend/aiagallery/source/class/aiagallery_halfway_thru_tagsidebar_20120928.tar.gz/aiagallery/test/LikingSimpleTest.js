/**
 * Copyright (c) 2011 Reed Spool
 * 
 * License:
 *   LGPL: http://www.gnu.org/licenses/lgpl.html 
 *   EPL : http://www.eclipse.org/org/documents/epl-v10.php
 */

qx.Class.define("aiagallery.test.LikingSimpleTest",
{
  extend : qx.dev.unit.TestCase,

  members :
  {

    "test 01: Simple Plus One Liking" : function()
    {
      // Get access to the RPC implementations. This includes the mixins for
      // all RPCs.
      var dbifSim = aiagallery.dbif.DbifSim.getInstance();

      // We need an error object
      var error = new liberated.rpc.error.Error("2.0");
      
      // Adding a new app.
      var myAppData = dbifSim.addOrEditApp(null,
                                           {
                                             owner    : "1002",
                                             description: "hello",
                                             title : "a title",
                                             tags :
                                             [
                                               "tag", 
                                               "anotherTag",
                                               "Business"
                                             ],
                                             source : "sources",
                                             image1 : "data://xxx"
                                           },
                                           error);

      // Ensure that the app got added properly
      this.assertNotEquals(error, myAppData,
                           "addOrEditApp failed: " + error.stringify());

      // Was this app initialized correctly with zero likes?
      this.assert(myAppData.numLikes === 0, "Num likes correctly inited to 0");
      
      var newNumLikes = dbifSim.likesPlusOne(myAppData.uid, error);
      
      // Did the plus one go well?
      this.assert(newNumLikes === 1, "NumLikes correctly incremented");
      
      // Can we make a bad request?
      var badRequestResults = dbifSim.likesPlusOne(-1, error);
      
      // And does it return an error?
      this.assert(badRequestResults === error, "Bad like request returns"
                                               + " error appropriately");

    }
  }
});
