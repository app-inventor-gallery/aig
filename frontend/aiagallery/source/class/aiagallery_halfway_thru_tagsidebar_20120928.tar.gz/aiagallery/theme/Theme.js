/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("aiagallery.theme.Theme",
{
  meta :
  {
    color : aiagallery.theme.Color,
    decoration : aiagallery.theme.Decoration,
    font : aiagallery.theme.Font,
    icon : qx.theme.icon.Tango,
    appearance : aiagallery.theme.Appearance
  }
});